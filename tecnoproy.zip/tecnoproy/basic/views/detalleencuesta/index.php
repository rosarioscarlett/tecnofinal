<?php

use yii\helpers\Html;
use yii\grid\GridView;

/* @var $this yii\web\View */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Detalleencuestas';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="detalleencuesta-index">

    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?= Html::a('Create Detalleencuesta', ['create'], ['class' => 'btn btn-success']) ?>
    </p>
    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            'iddetalleencuesta',
            'idencuesta',
            'idusuario',
            'idindicador',
            'descripcion',
            // 'respuesta',

            ['class' => 'yii\grid\ActionColumn'],
        ],
    ]); ?>
</div>
