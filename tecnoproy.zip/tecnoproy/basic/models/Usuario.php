<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "usuario".
 *
 * @property integer $idusuario
 * @property string $nombre
 * @property string $apellido
 * @property string $email
 * @property string $ci
 * @property integer $idtipousuario
 * @property integer $idfacultad
 * @property string $password
 */
class Usuario extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'usuario';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['nombre', 'email', 'ci', 'idtipousuario', 'idfacultad', 'password'], 'required'],
            [['idtipousuario', 'idfacultad'], 'integer'],
            [['nombre', 'apellido', 'email', 'ci', 'password'], 'string', 'max' => 250],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'idusuario' => 'Idusuario',
            'nombre' => 'Nombre',
            'apellido' => 'Apellido',
            'email' => 'Email',
            'ci' => 'Ci',
            'idtipousuario' => 'Idtipousuario',
            'idfacultad' => 'Idfacultad',
            'password' => 'Password',
        ];
    }
}
