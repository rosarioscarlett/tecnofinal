<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "indicador".
 *
 * @property integer $idindicador
 * @property string $descripcion
 * @property string $metrica
 * @property integer $idmodelo
 */
class Indicador extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'indicador';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['descripcion', 'idmodelo'], 'required'],
            [['idmodelo'], 'integer'],
            [['descripcion', 'metrica'], 'string', 'max' => 250],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'idindicador' => 'Idindicador',
            'descripcion' => 'Descripcion',
            'metrica' => 'Metrica',
            'idmodelo' => 'Idmodelo',
        ];
    }
}
