<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "encuesta".
 *
 * @property integer $idencuesta
 * @property integer $idfacultad
 * @property string $fechainicio
 * @property string $fechafin
 */
class Encuesta extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'encuesta';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['idfacultad', 'fechainicio', 'fechafin'], 'required'],
            [['idfacultad'], 'integer'],
            [['fechainicio', 'fechafin'], 'safe'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'idencuesta' => 'Idencuesta',
            'idfacultad' => 'Idfacultad',
            'fechainicio' => 'Fechainicio',
            'fechafin' => 'Fechafin',
        ];
    }
}
