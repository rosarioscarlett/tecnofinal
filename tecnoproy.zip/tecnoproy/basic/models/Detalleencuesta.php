<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "detalleencuesta".
 *
 * @property integer $iddetalleencuesta
 * @property integer $idencuesta
 * @property integer $idusuario
 * @property integer $idindicador
 * @property string $descripcion
 * @property string $respuesta
 */
class Detalleencuesta extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'detalleencuesta';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['idencuesta', 'idusuario', 'idindicador', 'descripcion'], 'required'],
            [['idencuesta', 'idusuario', 'idindicador'], 'integer'],
            [['descripcion'], 'string', 'max' => 1000],
            [['respuesta'], 'string', 'max' => 50],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'iddetalleencuesta' => 'Iddetalleencuesta',
            'idencuesta' => 'Idencuesta',
            'idusuario' => 'Idusuario',
            'idindicador' => 'Idindicador',
            'descripcion' => 'Descripcion',
            'respuesta' => 'Respuesta',
        ];
    }
}
